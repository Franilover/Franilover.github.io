"use client";

/**
 * MagiaPorTipo
 * ───────────────────────────────────────────────────────────────────────────
 * Vista de la página "Magia": tres bloques planos — Hechizos / Dones / Runas —
 * cada uno con su grid de tarjetas. Sin agrupar por criatura de origen (esa
 * relación fue eliminada; ahora hechizos/dones/runas no tienen `criatura_id`).
 */

import { Plus, ScrollText, Sparkles, Star } from "lucide-react";
import React, { useEffect, useMemo, useRef, useState } from "react";

import { EntityCard } from "@/domains/garlia/_shared/EntityCard";
import type { SectionKey } from "@/domains/garlia/_shared/useMundoNavigationStore";
import { RichEditor } from "@/editor/lexical";
import { useEnsayoEditorLogic } from "@/editor/notas/hooks/useEnsayoEditorLogic";

import { SubBloqueProbador } from "./BloqueHerramientasRunas";
import { BloqueSubsistemasMagia } from "./BloqueSubsistemasMagia";
import type { Punto } from "./dollarOneRecognizer";
import { EditorCombinacionesRunas } from "./EditorCombinacionesRunas";
import { RunaThumbnail } from "./RunaThumbnail";
import type { EntidadMagica } from "./types";

interface EntidadMagicaMin {
  id: string;
  nombre: string;
  imagen_url?: string | null;
  patron_trazos?: Punto[][] | null;
}

interface Props {
  hechizos: EntidadMagicaMin[];
  dones: EntidadMagicaMin[];
  runas: EntidadMagicaMin[];
  loading?: boolean;
  onOpen: (section: SectionKey, id: string) => void;
  onCreate?: (tipo: "hechizos" | "dones" | "runas") => void;
  creating?: boolean;
  // Abre un ensayo (tab "notas-gos") — mismo patrón que EnsayosGosWidget
  // en el home. Si no se pasa, el bloque de ensayos no se muestra.
  onOpenEnsayo?: (ensayoId: string) => void;
  // Catálogo completo de runas — para el bloque de herramientas de runas
  // (probador + editor de combinaciones), movido acá desde el editor
  // interno de una runa individual.
  todasLasRunas?: EntidadMagica[];
}

const BLOQUES = [
  { key: "hechizos" as const, label: "Hechizos", Icon: Sparkles, section: "hechizos" as SectionKey },
  { key: "dones" as const, label: "Dones", Icon: Star, section: "dones" as SectionKey },
  { key: "runas" as const, label: "Runas", Icon: ScrollText, section: "runas" as SectionKey },
];

function Bloque({
  label,
  Icon,
  section,
  entidades,
  onOpen,
  onCreate,
  creating,
  esRunas,
}: {
  label: string;
  Icon: React.ElementType;
  section: SectionKey;
  entidades: EntidadMagicaMin[];
  onOpen: (section: SectionKey, id: string) => void;
  onCreate?: () => void;
  creating?: boolean;
  esRunas?: boolean;
}) {
  return (
    <div className="rounded-lg border border-primary/10 overflow-hidden mb-6 last:mb-0">
      <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-1.5 px-3 py-3">
        <span />
        <span className="justify-self-center max-w-[280px] truncate text-micro font-bold uppercase tracking-[0.12em] text-primary/70">
          {label}
        </span>
        {onCreate ? (
          <button
            type="button"
            onClick={onCreate}
            disabled={creating}
            title={`Añadir ${label.toLowerCase()}`}
            className="justify-self-end p-1 rounded-full bg-primary/10 hover:bg-primary/20 transition-colors disabled:opacity-50 shrink-0"
          >
            <Plus size={9} className="text-primary/60" />
          </button>
        ) : (
          <span />
        )}
      </div>
      <div className="px-3 pb-3">
        {entidades.length === 0 ? (
          <div className="w-full py-6 text-xs text-primary/25 text-center">
            Sin {label.toLowerCase()} todavía
          </div>
        ) : (
          <div
            className="grid gap-1"
            style={{ gridTemplateColumns: "repeat(auto-fill, 52px)" }}
          >
            {entidades.map((e) => (
              <EntityCard
                key={e.id}
                nombre={e.nombre}
                imageUrl={esRunas ? null : e.imagen_url}
                Icon={Icon}
                visual={esRunas ? <RunaThumbnail patronTrazos={e.patron_trazos} /> : undefined}
                onClick={() => onOpen(section, e.id)}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Bloque de ensayo "Energias" (tag GOS + tag Magia) ─────────────────────
// Antes listaba todos los ensayos con ambas tags; ahora apunta a un ensayo
// único y fijo llamado "Energias" — se busca por título+tags, y si no existe
// todavía se crea automáticamente la primera vez que se abre Magia.
const TITULO_ENSAYO_ENERGIAS = "Energias";

function BloqueEnsayoEnergias(_props: { onOpenEnsayo?: (id: string) => void }) {
  const { ensayos, loading, crearNotaPendiente, actualizarLocal } = useEnsayoEditorLogic(null);
  const creandoRef = useRef(false);
  const [creando, setCreando] = useState(false);

  const ensayoEnergias = useMemo(
    () =>
      ensayos.find((e: any) => {
        const tags = (e.tags ?? []).map((t: string) => t.trim().toLowerCase());
        return (
          (e.titulo ?? "").trim().toLowerCase() === TITULO_ENSAYO_ENERGIAS.toLowerCase() &&
          tags.includes("gos") &&
          tags.includes("magia")
        );
      }),
    [ensayos],
  );

  // Auto-creación: solo una vez que terminó de cargar y confirmamos que no
  // existe. El ref evita que un doble-render dispare dos creaciones antes
  // de que el primer resultado llegue al estado.
  useEffect(() => {
    if (loading || ensayoEnergias || creandoRef.current) return;
    creandoRef.current = true;
    setCreando(true);
    void crearNotaPendiente(TITULO_ENSAYO_ENERGIAS, ["gos", "magia"]).finally(() => {
      setCreando(false);
      creandoRef.current = false;
    });
  }, [loading, ensayoEnergias, crearNotaPendiente]);

  if (loading || creando || !ensayoEnergias) {
    return (
      <div className="w-full py-6 text-xs text-primary/30 text-center mb-6">
        {creando ? "Creando ensayo…" : "Cargando…"}
      </div>
    );
  }

  return (
    <div className="mb-6">
      <RichEditor
        key={ensayoEnergias.id}
        value={ensayoEnergias.contenido || ""}
        onChange={(value) => actualizarLocal(ensayoEnergias.id, "contenido", value)}
        placeholder="Escribe aquí…"
        minHeight={220}
      />
    </div>
  );
}

export function MagiaPorTipo({
  hechizos,
  dones,
  runas,
  loading,
  onOpen,
  onCreate,
  creating,
  onOpenEnsayo,
  todasLasRunas,
}: Props) {
  const datos = { hechizos, dones, runas };

  if (loading && hechizos.length === 0 && dones.length === 0 && runas.length === 0) {
    return <div className="py-6 text-xs text-primary/30 text-center">Cargando…</div>;
  }

  // Sin onOpenEnsayo: comportamiento anterior, un solo bloque de columna.
  if (!onOpenEnsayo) {
    return (
      <div>
        {BLOQUES.map(({ key, label, Icon, section }) => (
          <Bloque
            key={key}
            Icon={Icon}
            entidades={datos[key]}
            esRunas={key === "runas"}
            label={label}
            section={section}
            creating={creating}
            onCreate={onCreate ? () => onCreate(key) : undefined}
            onOpen={onOpen}
          />
        ))}
      </div>
    );
  }

  // Vista dividida: mitad izquierda = items (Hechizos/Dones/Runas),
  // mitad derecha = ensayos con tag GOS + Magia.
  return (
    <div className="flex flex-col lg:flex-row gap-6">
      <div className="flex-1 min-w-0">
        {BLOQUES.map(({ key, label, Icon, section }) => (
          <Bloque
            key={key}
            Icon={Icon}
            entidades={datos[key]}
            esRunas={key === "runas"}
            label={label}
            section={section}
            creating={creating}
            onCreate={onCreate ? () => onCreate(key) : undefined}
            onOpen={onOpen}
          />
        ))}
        <BloqueSubsistemasMagia />
        {todasLasRunas && (
          <SubBloqueProbador runas={todasLasRunas} />
        )}
      </div>
      <div className="flex-1 min-w-0">
        <BloqueEnsayoEnergias />
        {todasLasRunas && (
          <EditorCombinacionesRunas runas={todasLasRunas} />
        )}
      </div>
    </div>
  );
}
